#include <stdio.h>
#include <stdlib.h>

int pilihan;
typedef struct
{
    int saldo;
    int nabung;

} rekening;

    rekening rekeningPengguna = {50000};
