#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// identifikasi sebuah array untuk menyimpan nilai hitungan Fibonacci sebelumnya 
#define MAX 100
long long memo[MAX];