#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

typedef struct{
	char nama[100];
	int nilai;
}data[100];
data mhs;
void urut();
void input();
void print();
